import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class CartFrame extends JFrame {
    public CartFrame() {
        setTitle("Cart");
        setSize(300, 200);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JTextArea cartArea = new JTextArea();
        cartArea.setEditable(false);

        StringBuilder sb = new StringBuilder("Items in cart:\n\n");
        int total = 0;
        for (Product p : ProductFrame.cart) {
            sb.append(p.name).append(" - Rs.").append(p.price).append("\n");
            total += p.price;
        }
        sb.append("\nTotal: Rs.").append(total);
        cartArea.setText(sb.toString());

        add(new JScrollPane(cartArea));
    }
}