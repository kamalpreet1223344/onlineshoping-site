# 🛍️ Java Swing eCommerce App (In-Memory Version)

## ✅ Features
- User login (hardcoded credentials)
- Product browsing
- Add to cart and view cart
- No database needed – everything is stored in memory

## 🔑 Login
- Username: `admin`
- Password: `admin123`

## ▶️ How to Run
1. Open the project in a Java IDE (Eclipse, IntelliJ, etc.)
2. Compile and run `Main.java`

## 📦 Structure
- `Product.java` – Product model
- `LoginFrame.java` – Login screen
- `ProductFrame.java` – List of products with add-to-cart option
- `CartFrame.java` – View selected cart items

Happy Coding!