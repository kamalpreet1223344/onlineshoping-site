import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ProductFrame extends JFrame {
    DefaultListModel<Product> productListModel = new DefaultListModel<>();
    JList<Product> productList = new JList<>(productListModel);
    static ArrayList<Product> cart = new ArrayList<>();

    public ProductFrame() {
        setTitle("Products");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        // Sample products
        productListModel.addElement(new Product("Laptop", 50000));
        productListModel.addElement(new Product("Phone", 25000));
        productListModel.addElement(new Product("Headphones", 2000));

        JButton addToCartBtn = new JButton("Add to Cart");
        JButton viewCartBtn = new JButton("View Cart");

        addToCartBtn.addActionListener(e -> {
            Product selected = productList.getSelectedValue();
            if (selected != null) {
                cart.add(selected);
                JOptionPane.showMessageDialog(this, selected.name + " added to cart!");
            }
        });

        viewCartBtn.addActionListener(e -> new CartFrame().setVisible(true));

        JPanel btnPanel = new JPanel();
        btnPanel.add(addToCartBtn);
        btnPanel.add(viewCartBtn);

        panel.add(new JScrollPane(productList), BorderLayout.CENTER);
        panel.add(btnPanel, BorderLayout.SOUTH);
        add(panel);
    }
}